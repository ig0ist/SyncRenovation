#!/bin/sh

# Mod Name      : Remove Unsupported HUB Alert && Add custom VID/PID HUB
# Author        : uaid | www.fmods.net
# Creation date : 2022-05-02
# Version       : 1.0
# Update date   : 2022-05-02

###########################################
#   Functions                             #
###########################################

POPUP=/tmp/popup.txt
echo "" > $POPUP

function displayMessage {
    echo "${1}" >> $POPUP
    /fs/rwdata/dev/utserviceutility popup $POPUP
}

function reboot {
    /fs/rwdata/dev/utserviceutility reboot
}

function displayImage {
	slay APP_SUM
	slay -s 9 NAV_Manager
	slay -s 9 fordhmi
	slay HMI_AL
	display_image -file=/fs/usb0/SyncMyMod/installation_${1}.png -display=2 &

	while [ -e /fs/usb0 ]; do
		sleep 1
	done

	reboot

	exit 0
}


chmod a+x /fs/rwdata/dev/*

###########################################
#   Remount FS as RW                      #
###########################################

. /fs/rwdata/dev/remount_rw.sh
sleep 1

###########################################
#   Copying new files                     #
###########################################

cp -r /fs/usb0/SyncMyMod/allowed_hubs.xml /fs/mp/etc/allowed_hubs.xml
cp -r /fs/usb0/SyncMyMod/carplay_allowed_hubs.xml /fs/mp/etc/carplay_allowed_hubs.xml

###########################################
#   Remount FS as RO                      #
###########################################

sleep 1
. /fs/rwdata/dev/remount_ro.sh
sync
sync
sync

###########################################
#   Display success image and reboot      #
###########################################

displayImage "completed"
