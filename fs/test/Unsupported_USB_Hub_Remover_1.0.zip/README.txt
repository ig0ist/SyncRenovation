//**********************************************************************************************************************************************************************//
//                                                                                                                                                                 		//
//                 AAA                                TTTTTTTTTTTTTTTTTTTTTTTEEEEEEEEEEEEEEEEEEEEEE               AAA               MMMMMMMM               MMMMMMMM		//
//                A:::A                               T:::::::::::::::::::::TE::::::::::::::::::::E              A:::A              M:::::::M             M:::::::M		//
//               A:::::A                              T:::::::::::::::::::::TE::::::::::::::::::::E             A:::::A             M::::::::M           M::::::::M		//
//              A:::::::A                             T:::::TT:::::::TT:::::TEE::::::EEEEEEEEE::::E            A:::::::A            M:::::::::M         M:::::::::M		//
//             A:::::::::A                            TTTTTT  T:::::T  TTTTTT  E:::::E       EEEEEE           A:::::::::A           M::::::::::M       M::::::::::M		//
//            A:::::A:::::A                                   T:::::T          E:::::E                       A:::::A:::::A          M:::::::::::M     M:::::::::::M		//
//           A:::::A A:::::A                                  T:::::T          E::::::EEEEEEEEEE            A:::::A A:::::A         M:::::::M::::M   M::::M:::::::M		//
//          A:::::A   A:::::A         ---------------         T:::::T          E:::::::::::::::E           A:::::A   A:::::A        M::::::M M::::M M::::M M::::::M		//
//         A:::::A     A:::::A        -:::::::::::::-         T:::::T          E:::::::::::::::E          A:::::A     A:::::A       M::::::M  M::::M::::M  M::::::M		//
//        A:::::AAAAAAAAA:::::A       ---------------         T:::::T          E::::::EEEEEEEEEE         A:::::AAAAAAAAA:::::A      M::::::M   M:::::::M   M::::::M		//
//       A:::::::::::::::::::::A                              T:::::T          E:::::E                  A:::::::::::::::::::::A     M::::::M    M:::::M    M::::::M		//
//      A:::::AAAAAAAAAAAAA:::::A                             T:::::T          E:::::E       EEEEEE    A:::::AAAAAAAAAAAAA:::::A    M::::::M     MMMMM     M::::::M		//
//     A:::::A             A:::::A                          TT:::::::TT      EE::::::EEEEEEEE:::::E   A:::::A             A:::::A   M::::::M               M::::::M		//
//    A:::::A               A:::::A                         T:::::::::T      E::::::::::::::::::::E  A:::::A               A:::::A  M::::::M               M::::::M		//
//   A:::::A                 A:::::A                        T:::::::::T      E::::::::::::::::::::E A:::::A                 A:::::A M::::::M               M::::::M		//
//  AAAAAAA                   AAAAAAA                       TTTTTTTTTTT      EEEEEEEEEEEEEEEEEEEEEEAAAAAAA                   AAAAAAAMMMMMMMM               MMMMMMMM		//
//                                                                                                                                                                 		//
//**********************************************************************************************************************************************************************//
//*********************************************************** Remove Unsupported HUB Alert && Add custom VID/PID HUB ***************************************************//
//*																																									   *//
//* Developed by uaid																																				   *//
//*																																									   *//
//* www.fmods.net																															   		  				   *//
//*																																									   *//
//*************************************************************************** HOW TO USE *******************************************************************************//
//*																																									   *//
//*	This mod add custom PIDs and VIDs to suppress the Unsupported USB HUB message that appear when you are not using an OEM USB HUB or an additional USB HUB		   *//
//*	Please note that YOU MUST insert the PID and VID of your USB HUB inside the BOTH the XML files (allowed_hubs.xml and carplay_allowed_hubs.xml) that you can	   	   *//
//*	find in the SyncMyMod folder.																															   		   *//
//*	To find your device PID and VID you can use your PC (here a guide  https://www.betterhostreview.com/find-vid-pid-usb-device-pc.html)			  		   		   *//
//*																																									   *//
//**********************************************************************************************************************************************************************//
//*																																									   *//
//***************************************************************************** CHANGELOG ******************************************************************************//
//*																																									   *//
//* ## v1.0 - 2022-05-02																																			   *//
//* - Initial Release																													   							   *//
//*																																									   *//
//**********************************************************************************************************************************************************************//